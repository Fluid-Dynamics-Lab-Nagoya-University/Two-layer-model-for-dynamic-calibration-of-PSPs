function[Result]=transfer_function_doublelayer_I_Iref(freq,dl1,dl2,D1,D2,hf,tau)
    dl2=dl1+dl2;
    %% Prepare parameter
    img  = 0 + 1i ;
    quath  = 0.5 + 0.5i ;
    quat  = 1 + 1i ;

    %% 
      nmax=1000;
      C=zeros(nmax+2,1);
      I=zeros(nmax+2,1);
      F=zeros(nmax+2,1);

%       fac=10^(1d0/5d0);
%       freq=0.001/fac;
      ii=1;
    while  ii<=length(freq)
      frequency=freq(ii);
      omega=2d0*pi*frequency;
      dk1=sqrt(2d0*omega/D1);
      dk2=sqrt(2d0*omega/D2);

      for n=1:nmax+1
         z =(n-1)/(nmax)*dl1;
         C(n)    =  exp(-1d0*quath*z*dk1).* ...
               ((sqrt(D1)*(exp(quat*dl1*dk2)+exp(quat*dl2*dk2)).*...
                           (exp(quat*dl1*dk1)+exp(quat*z  *dk1)))-...
               (sqrt(D2)*(exp(quat*dl1*dk2)-exp(quat*dl2*dk2)).*...
                           (exp(quat*dl1*dk1)-exp(quat*z  *dk1))))./...
               ((sqrt(D1)*(exp(quat*dl1*dk2)+exp(quat*dl2*dk2)).*...
                           (exp(quat*dl1*dk1)+             1d0 ))-...
               (sqrt(D2)*(exp(quat*dl1*dk2)-exp(quat*dl2*dk2)).*...
                           (exp(quat*dl1*dk1)-             1d0 ))) ;
         I(n)    =C(n)/(1d0+img*tau*omega);
         F(n)    =exp(-z*hf);
      end

      TotalIref=0;
      TotalI   =0;

      for n=1:nmax+1
         z1 =(n-1)/(nmax)*dl1;
         z2 =(n  )/(nmax)*dl1;
         dz =z2-z1;
         TotalIref=TotalIref+0.5d0*(F(n)     +F(n+1)       );
         TotalI   =TotalI   +0.5d0*(F(n)*I(n)+F(n+1)*I(n+1));
      end
      
      Freq_result(ii,1)=frequency;
      Total_I_Iref(ii,1)=TotalI/TotalIref;
      Real_Total_I_Iref(ii,1)=real(Total_I_Iref(ii,1));
      Real_Imag_Total_I_Iref(ii,1)=real(imag(Total_I_Iref(ii,1)));
      
      ii=ii+1;
    end
    Result=horzcat(Real_Total_I_Iref,Real_Imag_Total_I_Iref);
end