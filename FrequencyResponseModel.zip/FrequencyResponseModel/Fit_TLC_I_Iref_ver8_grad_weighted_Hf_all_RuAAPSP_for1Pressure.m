clc
clear all;
close all;
set(0,'DefaultAxesFontSize',12);
set(0,'DefaultAxesFontName','Times');
set(0,'DefaultTextFontSize',12);
set(0,'DefaultTextFontName','Times');
set(0,'DefaultLineLineWidth',0.5);
Color=[1 0 0; 0 0.5 0;0 0.9 1;0 0 1;0 0 0;1 0 0;0 0 0;0.56 0 0.8; 0 0 1;0.0 0.7 0.3 ;1 0.8 0.1;1 0 0;1 0 1;0 1 0;1 1 1;0.56 0 0.8; 0 0 1;0.0 0.7 0.3 ;1 0.8 0.1;1 0 0;1 0 1;0 1 0;1 1 1];%0.56 0 0.8;
% Color=[1 0 0; 0 0 1;0.56 0 0.8; 0.314 0.455 0.243; 1 0 1;0 1 0;1 1 1];
%% Graph rule %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
xlabel_name='\itf \rm[Hz]';
ylabel_name_Gain='Gain [dB]';
ylabel_name_Phase='Phase [deg]';
x_lim=[100 20000];
y_lim_gain=[-10 2];
y_lim_phase=[-100 20];
%% name (input)
%Data=csvread(['Gain-Phase_AAPSP_Ru.csv'],2,0);  %読み込むファイル名
%outdir='fig_AAPSP_Ru_all\';                     %出力ディレクトリ作成
Data = xlsread('RTV-Rudpp.xlsx','A2:E34');
[~, idx] = sort(Data(:,1));   % 按第一列排序得到排序 index
Data = Data(idx,:);           % 全部行按照 idx 重排
outdir='fig_RTVPSP\';                     %出力ディレクトリ作成
title1='Gain';
title2='Phase';
legend_name={'100kPa','50kPa','20kPa','10kPa','5kPa'};
figsize=[300 100 400 350];
marker_size=8;
%% intial value
%known
%dl1=10.2d-6;                                        %膜厚：計測値
%dl1=9.8d-6;  %AA-H2TCPP
%dl1=18.7d-6;  %IBM-PtTFPP
dl1=15.5d-6;  %RTV-Ru
dl2=0;                                              %0
%tau=[0.182294319, 0.237740885,0.382737346,0.522700859,0.530339964]; %寿命：計測値，１圧力分なら1つ
%tau =[0.0023]; % H2TCPP
%tau =[25]; % Pt
tau =[8.4]; % Ru
tau=tau*10^(-6);
%estimate
%D1_ini=1.54d-6;                                     %拡散係数の初期値：適当に与えてみる
D1_ini=1.54d-5; 
hf_ini=0;                                           %0
%% 
%Data(25,:)=[];  %不適データ削除
[m,n]=size(Data);                                   %１圧力分のデータにしておく
%n = 5;
nGainPhase=zeros(m,(n-1)/4);
% Data(Data==0)=nan;
Cond=Data(:,1); Data(:,1)=[];
for i=1:(n-1)/4
    Gain(:,i)=Data(:,(i-1)*4+1);
    Gain_Std(:,i)=Data(:,(i-1)*4+2);
    Phase(:,i)=Data(:,(i-1)*4+3);
    Phase_Std(:,i)=Data(:,(i-1)*4+4);
end

x=Cond;
mkdir(outdir);   
%% Gain Phase to TotalI/TotalIref
for i=1:(n-1)/4
    A=sqrt((10.^(Gain(:,i)/10))./(1+tan(Phase(:,i).*pi()/180).^2));
    B=A.*tan(Phase(:,i).*pi()/180);
    y(:,:,i)=horzcat(A,B);

    A_Std=sqrt((10.^(Gain_Std(:,i)/10))./(1+tan(Phase_Std(:,i).*pi()/180).^2));
    B_Std=A_Std.*tan(Phase_Std(:,i).*pi()/180);

    weight(:,i)=1./sqrt(A_Std.^2+B_Std.^2);
end

% weight(1:20,1)=1; 
% % weight(21:26,1)=1;
% weight(21:26,1)=[1.1;1.2;1.3;1.4;1;1];
%% Gradient
hf=hf_ini;
f_=zeros(1,1);
dx_=1d3;    
step_=1d7;	
epsi_=1d-30;
resi_=1d5;

    f=zeros(1,1);
    %step
    dx=1d-9;    
    step=1d-5;	
    epsi=1d-20;
    resi=1d5;
    D1=D1_ini; 
    fixed_variables=D1;
    for i=1:(n-1)/4
        %% first calcluate
         y_est=transfer_function_doublelayer_I_Iref(x,dl1,0,D1,D1,hf,tau(1,i));
         [design_variable_temp,obj_func_temp]=gradient_response_D1(fixed_variables,dx,step,epsi,resi,...
            y(:,:,i),y_est,x,dl1,dl2,hf,tau(1,i),weight(:,i));
        design_variable(1,i)=design_variable_temp;
        obj_func(1,i)=obj_func_temp;
         fixed_variables=design_variable(1,i);
    end

%% write matrix
Label=["coef D1(100kPa)","hf"];
% Label=["coef D1(100kPa)","coef D1(50kPa)","coef D1(20kPa)","coef D1(10kPa)","coef D1(5kPa)","hf"];
coef=horzcat(design_variable,hf);
Error_meas=vertcat(Label,coef);
writematrix(Error_meas,[outdir 'coef_ave.xlsx']);

% calculate gain and phase
for i=1:(n-1)/4
Result_est_min(:,:,i)=transfer_function_doublelayer(x,dl1,dl2,design_variable(1,i),...
       design_variable(1,i),hf,tau(1,i));
writematrix(Result_est_min,[outdir 'Est_Gain_Phase' num2str(i) '.xlsx']);
end

%% figure output
for i=1:(n-1)/4
    figure(i)
     hAx=axes;
    errorbar(Cond(:,1),Gain(:,i),Gain_Std(:,i),'o','Color',Color(1,:,:),'MarkerSize',marker_size); hold on;
    plot(x,Result_est_min(:,1,i),'Color',Color(2,:,:))
    hold on;
     hAx.XScale='log';
    % legend(legend_name,'FontSize',10,'Location','eastoutside');
    set(gcf,'Position',figsize);
    grid on;
    xlabel(xlabel_name)
    ylabel(ylabel_name_Gain)
    xticks([100 1000 10000])
    xticklabels({'100','1000','10000'})
    xlim(x_lim)
    ylim(y_lim_gain)
    saveas(gcf,[ outdir title1 num2str(i) '.fig']);
    saveas(gcf,[ outdir title1 num2str(i)  '.tif']);
    saveas(gcf,[ outdir title1 num2str(i)  '.svg']);
    % saveas(gcf,[ outdir title1  '.eps']);


    figure(i*10)
     hAx=axes;
    errorbar(Cond(:,1),Phase(:,i),Phase_Std(:,i),'o','Color',Color(1,:,:),'MarkerSize',marker_size); hold on;
    plot(x,Result_est_min(:,2,i),'Color',Color(2,:,:))
    hold on;
     hAx.XScale='log';  
    % legend(legend_name,'FontSize',10,'Location','eastoutside');
    set(gcf,'Position',figsize);
    grid on;
    xticks([100 1000 10000])
    xticklabels({'100','1000','10000'})
    xlabel(xlabel_name)
    ylabel(ylabel_name_Phase)
    xlim(x_lim)
    ylim(y_lim_phase)
    saveas(gcf,[ outdir title2 num2str(i)  '.fig']);
    saveas(gcf,[ outdir title2 num2str(i)  '.tif']);
    saveas(gcf,[ outdir title2 num2str(i)  '.svg']);
end