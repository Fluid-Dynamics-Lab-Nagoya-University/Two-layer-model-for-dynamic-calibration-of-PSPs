function[design_variable,obj_func]=gradient_response_D1(fixed_variables,dx,step,epsi,resi,...
    y,y_est,x,dl1,dl2,hf,tau,weight)
%% Gradient
    f=zeros(2,1);    
    %step
    ii=0;
    obj_func=norm((y-y_est).*weight,'fro')^2;
    % variable input
    design_variable=fixed_variables;
    [~,jmax]=size(fixed_variables);

      while epsi < resi || ii < 10
            ii=ii+1;
            design_variable_old=design_variable;
            for j=1:jmax %x,y
                for k=1:2 %forward backward
                    moving_points_tmp=design_variable;
                    if(k == 1)
                            moving_points_tmp(1,j)=design_variable(1,j)+dx(1,j);
                    elseif(k == 2)
                            moving_points_tmp(1,j)=design_variable(1,j)-dx(1,j);
                    end
                    y_est=transfer_function_doublelayer_I_Iref(x,dl1,dl2,moving_points_tmp(1,1),moving_points_tmp(1,1),...
                       hf,tau);
                    f(k)=(norm((y-y_est).*weight,'fro'))^2;
                end
                gradf(1,j)=(f(1)-f(2))/2/dx(1,j);
            end
            obj_func_old=obj_func;
            while(1)
                design_variable=design_variable_old-step.*gradf;            
                y_est=transfer_function_doublelayer_I_Iref(x,dl1,dl2,design_variable(1,1),design_variable(1,1),...
                        hf,tau);          
                obj_func=(norm((y-y_est).*weight,'fro'))^2 ;   
                if(obj_func < obj_func_old)
                    break;
                end
                step=step/2;
                if(step < 1e-20)
                    break;
                end
            end
            resi=abs(obj_func_old-obj_func);
            disp(['itr: ' num2str(ii),', resi: ', num2str(resi), ', step: ', num2str(step), ', val: ', num2str(obj_func)])
            step=step*2;
     end
end
